function Concluir() {
  let Nome = document.getElementById("Nome").value;
  let Email = document.getElementById("Email").value;
  let DataNascimento = document.getElementById("DataNasc").value;
  let CelularPrincipal = parseInt(document.getElementById("CelP").value);
  let TelefoneResidencial = parseInt(document.getElementById("CelR").value);

  // Genero
  let Genero = document.querySelector('input[name="genero"]:checked');
  let resultadoGen;

  if (Genero) {
    let value = Genero.value;
    resultadoGen = "Você escolheu: " + value;
  } else {
    resultadoGen = "Você não escolheu nenhum gênero.";
  }
  //Fim genero

  let Ingresso = document.getElementById("Ingresso").value;

  let conclusao = `<p><strong>Nome:</strong> ${Nome}</p>
    <p><strong>Email:</strong> ${Email}</p>
    <p><strong>Data de Nascimento:</strong> ${DataNascimento}</p>
    <p><strong>Celular Principal:</strong> ${
      isNaN(CelularPrincipal) ? "Não informado" : CelularPrincipal
    }</p>
    <p><strong>Telefone Residencial:</strong> ${
      isNaN(TelefoneResidencial) ? "Não informado" : TelefoneResidencial
    }</p>
    <p><strong>Gênero:</strong> ${resultadoGen}</p>
    <p><strong>Ingresso:</strong> ${Ingresso}</p>`;
  document.getElementById("conclusao").innerHTML = conclusao;

  alert("Dados enviados com sucesso!");
}
