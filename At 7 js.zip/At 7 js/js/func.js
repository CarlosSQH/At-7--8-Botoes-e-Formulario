function botao1() {
  let click1 = window.alert("Você clicou no Botão 1");
}

function botao2() {
  let click1 = window.alert("Você clicou no Botão 2");
}

function botao3() {
  let click1 = window.alert("Você clicou no Botão 3");
}
